USE master
GO
CREATE DATABASE Bibliothek;
GO
